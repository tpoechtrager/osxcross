#include "Object.h"

@interface Protocol : Object @end
