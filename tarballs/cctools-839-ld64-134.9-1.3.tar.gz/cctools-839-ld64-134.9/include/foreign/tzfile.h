//fake headers, for ar
#include <time.h>
